# Prerequisites:

Python (3.6+)
Jupyter Notebook or JupyterLab

# Steps to Run:
1. In the terminal, navigate to 2232890_2233114_2232783.ipynb file directory
cd path/to/your/notebook

2. Launch Jupyter using:
Jupyter notebook

3. Open the .ipynb file in the browser.

4. Run the notebook:
press Cell > Run All or Run > Run All Cells.
